export const aa = 'https://aa.com';
