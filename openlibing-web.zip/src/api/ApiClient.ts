import axios, { AxiosRequestConfig, AxiosResponse } from 'axios';
import { parseRestfulUrl } from '@/utils/tools';

const methods = ['get', 'post', 'put', 'patch', 'delete'];
const sourceTokenMap = {};

export interface ApiClientSetting {
    canCancel?: boolean; // 连续调用可中断上次请求
    fullRes?: boolean; // 需要获取响应得所有数据请配置
    restfulParams?: any; // restfull接口的替换映射对象
}

type ApiRequestFunc = (
    p: string,
    a: AxiosRequestConfig,
    s: ApiClientSetting,
) => AxiosResponse<any, any> | any;

export default class ApiClient {
    get: ApiRequestFunc;
    post: ApiRequestFunc;
    put: ApiRequestFunc;
    patch: ApiRequestFunc;
    delete: ApiRequestFunc;

    constructor() {
        methods.forEach(method => {
            this[method] = async (path, axiosConfig, setting: ApiClientSetting = {}) => {
                const { canCancel = false, fullRes = false, restfulParams } = setting;

                const requestConfig = { ...axiosConfig };

                if (canCancel) {
                    sourceTokenMap[path]?.cancel();

                    sourceTokenMap[path] = axios.CancelToken.source();
                    requestConfig.cancelToken = sourceTokenMap[path].token;
                }

                requestConfig.headers = {
                    'Content-Type': 'application/json; charset=UTF-8',
                    ...requestConfig.headers,
                };

                const config = {
                    url: restfulParams ? parseRestfulUrl(path, restfulParams) : path,
                    method,
                    withCredentials: true,
                    ...requestConfig,
                };

                return axios(config)
                    .then(res => {
                        const { data } = res;

                        return fullRes ? res : data;
                    })
                    .catch(error => {
                        return Promise.reject(error);
                    });
            };
        });
    }
}
