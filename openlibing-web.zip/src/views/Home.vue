<template>
    <div class="home">
        <span>Home 经过鉴权</span>
    </div>
</template>

<style></style>
