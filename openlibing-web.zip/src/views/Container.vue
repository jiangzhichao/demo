<script setup lang="ts">
/*
  需要鉴权的组件都存放在container下面
 */
import { RouterView } from 'vue-router';
</script>

<template>
    <RouterView />
</template>
