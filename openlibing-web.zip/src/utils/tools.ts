export const parseRestfulUrl = (url: string, restfulParams: any): string => {
    let tmpUrl = url;

    Object.keys(restfulParams).forEach(
        key => (tmpUrl = tmpUrl.replace(`{${key}`, restfulParams[key])),
    );

    return tmpUrl;
};
