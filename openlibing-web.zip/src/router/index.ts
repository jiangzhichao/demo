import { createRouter, createWebHistory } from 'vue-router';

const Login = () => import('../views/Login.vue');
const About = () => import('../views/AboutView.vue');
const Container = () => import('../views/Container.vue');
const Home = () => import('../views/Home.vue');

const router = createRouter({
    history: createWebHistory(import.meta.env.BASE_URL),
    routes: [
        {
            path: '/',
            name: 'login',
            component: Login,
        },
        {
            path: '/',
            name: 'container',
            component: Container,
            children: [
                {
                    path: 'home',
                    name: 'home',
                    component: Home,
                },
            ],
        },
        {
            path: '/about',
            name: 'about',
            component: About,
        },
    ],
} as any);

export default router;
