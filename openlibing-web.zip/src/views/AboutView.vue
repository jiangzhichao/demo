<template>
    <div class="about">
        <span>This is an about page</span>
    </div>
</template>

<style></style>
