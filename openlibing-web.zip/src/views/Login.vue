<script setup lang="ts">
import { getAA } from '@/api/api';

getAA({ params: { aa: 'aa' } }, { canCancel: true }).then(res => res);
</script>

<template>
    <div>这是登录</div>
</template>
