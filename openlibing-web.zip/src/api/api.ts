import ApiClient, { ApiClientSetting } from '@/api/ApiClient';
import * as urls from './url';
import { AxiosPromise, AxiosRequestConfig } from 'axios';

type RequestFunc = (a: AxiosRequestConfig, s: ApiClientSetting) => AxiosPromise<any> | Promise<any>;

const apiClient = new ApiClient();

export const getAA: RequestFunc = (a, s) => apiClient.get(urls.aa, a, s);
